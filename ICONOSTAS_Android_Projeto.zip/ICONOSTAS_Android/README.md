# ICONOSTAS — app Android

Aplicativo Android nativo simples que abre **https://iconostas-eo.chess777.workers.dev/** dentro de uma WebView, sem abrir o Chrome ao navegar no site.

## O que faz
- Abre o site automaticamente ao iniciar.
- Mantém as páginas HTTP**S** dentro do aplicativo (sem abrir navegador externo).
- Aceita JavaScript, armazenamento local e cookies para o funcionamento do jogo e das contas.
- O botão Voltar do Android volta para a página anterior.
- Mostra indicador de carregamento e tela de erro com **Tentar novamente**.
- Suporta escolha de arquivos pelo site (por exemplo, avatar/perfil).
- Carrega o site online: **é preciso acesso à internet**, e a disponibilidade depende do servidor.

## Gerar o APK SEM Android Studio (GitHub)
1. Crie um repositório novo no GitHub (pode ser privado).
2. Abra o ZIP e envie **todo o conteúdo da pasta `ICONOSTAS_Android`** para a raiz do repositório. Inclua a pasta oculta `.github` (workflow).
3. Confirme o envio na branch `main` ou `master`.
4. No GitHub, entre em **Actions > Gerar APK ICONOSTAS > Run workflow**. Se Actions estiver desabilitado, habilite-o no repositório.
5. Aguarde a tarefa terminar com sucesso. Abra a execução e baixe **ICONOSTAS-APK** em *Artifacts*.
6. Extraia o ZIP baixado e transfira `app-debug.apk` para o seu celular Android para instalar.

**Observação:** O arquivo debug é para teste. Publicar na Play Store requer pacote de lançamento assinado, política de privacidade e respeito aos direitos de marca/site.

## Gerar no Android Studio
1. Abra a pasta `ICONOSTAS_Android` pelo menu **Open**.
2. Aguarde o sincronismo Gradle (Android SDK 35 e Java 17).
3. Acesse **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. APK: `app/build/outputs/apk/debug/app-debug.apk`.

## Personalizar
- Endereço inicial: `MainActivity.java` -> constante `HOME`.
- Nome do app: `app/src/main/res/values/strings.xml`.
- Ícone do app: `app/src/main/res/mipmap-*` (arquivos PNG), e `mipmap-anydpi-v26` (ícone adaptativo).
- Pacote: `com.iconostas.launcher` em `app/build.gradle`.

## Notas técnicas
O app usa apenas a WebView do Android, sem anúncios, analytics, servidores intermediários ou APIs pagas. A autenticação acontece no próprio site e é gerenciada pelo WebView. Os dados transmitidos ao site obedecem à política do próprio site. Não é um cliente de xadrez offline. Alguns recursos externos do site que exigem outro app ou protocolos especiais podem não funcionar no wrapper. Teste login, cadastro, jogo online e pagamentos (se existirem) antes de distribuir. A publicação requer autorização do titular da plataforma/identidade visual.
