package com.iconostas.launcher;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.SafeBrowsingResponse;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.graphics.Color;
import android.graphics.Typeface;

public class MainActivity extends Activity {
    private static final String HOME = "https://iconostas-eo.chess777.workers.dev/";
    private static final int FILE_REQUEST = 1512;
    private WebView webView;
    private ProgressBar loadBar;
    private LinearLayout errorPanel;
    private ValueCallback<Uri[]> chooserCallback;
    private boolean mainFrameFailed;

    private int dp(float value) { return (int) (value * getResources().getDisplayMetrics().density + .5f); }

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(17,18,15));
        getWindow().setNavigationBarColor(Color.rgb(17,18,15));

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(17,18,15));
        webView = new WebView(this);
        root.addView(webView, new FrameLayout.LayoutParams(-1,-1));

        loadBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        loadBar.setMax(100);
        loadBar.setProgressTintList(android.content.res.ColorStateList.valueOf(Color.rgb(213,232,102)));
        FrameLayout.LayoutParams progressParams = new FrameLayout.LayoutParams(-1, dp(3), Gravity.TOP);
        root.addView(loadBar, progressParams);

        errorPanel = new LinearLayout(this);
        errorPanel.setOrientation(LinearLayout.VERTICAL);
        errorPanel.setGravity(Gravity.CENTER);
        errorPanel.setPadding(dp(30),dp(30),dp(30),dp(30));
        errorPanel.setBackgroundColor(Color.rgb(17,18,15));
        TextView title = new TextView(this);
        title.setText(R.string.offline);
        title.setTextColor(Color.WHITE);
        title.setTextSize(20);
        title.setTypeface(null, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        errorPanel.addView(title);
        TextView subtitle = new TextView(this);
        subtitle.setText(R.string.offline_sub);
        subtitle.setTextColor(Color.rgb(180,180,175));
        subtitle.setTextSize(14);
        subtitle.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams subParams = new LinearLayout.LayoutParams(-1,-2);
        subParams.setMargins(0,dp(14),0,dp(25));
        errorPanel.addView(subtitle,subParams);
        Button retry = new Button(this);
        retry.setText(R.string.retry);
        retry.setTextColor(Color.rgb(14,16,12));
        retry.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(213,232,102)));
        retry.setOnClickListener(v -> retry());
        errorPanel.addView(retry);
        errorPanel.setVisibility(View.GONE);
        root.addView(errorPanel,new FrameLayout.LayoutParams(-1,-1));
        setContentView(root);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true); // Necessário para a interface de jogo.
        settings.setDomStorageEnabled(true); // Preferências e sessão do site.
        settings.setDatabaseEnabled(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setSupportMultipleWindows(false); // Mantém navegação na mesma WebView.
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(true); // Necessário para o seletor de fotos.
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setUseWideViewPort(true);
        settings.setLoadWithOverviewMode(true);
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);

        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                if (!request.isForMainFrame()) return false;
                Uri uri = request.getUrl();
                String scheme = uri.getScheme();
                // Sites http(s) continuam no aplicativo; outras URLs são recusadas.
                // Não enviamos o usuário para o Chrome ou outro navegador.
                return !("https".equalsIgnoreCase(scheme));
            }
            @Override public void onPageStarted(WebView view, String url, Bitmap icon) {
                mainFrameFailed = false;
                errorPanel.setVisibility(View.GONE);
                loadBar.setVisibility(View.VISIBLE);
                super.onPageStarted(view,url,icon);
            }
            @Override public void onPageFinished(WebView view, String url) {
                CookieManager.getInstance().flush();
                if (mainFrameFailed) errorPanel.setVisibility(View.VISIBLE);
                super.onPageFinished(view,url);
            }
            @Override public void onReceivedError(WebView view, WebResourceRequest req, WebResourceError error) {
                if (req.isForMainFrame()) {
                    mainFrameFailed = true;
                    errorPanel.setVisibility(View.VISIBLE);
                    loadBar.setVisibility(View.GONE);
                }
            }
            @Override public void onSafeBrowsingHit(WebView view, WebResourceRequest req,
                                                     int threatType, SafeBrowsingResponse response) {
                response.backToSafety(true);
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public void onProgressChanged(WebView view, int progress) {
                loadBar.setProgress(progress);
                if (progress >= 100) loadBar.setVisibility(View.GONE);
            }
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                                                         FileChooserParams params) {
                if (chooserCallback != null) chooserCallback.onReceiveValue(null);
                chooserCallback = callback;
                try {
                    Intent intent = params.createIntent();
                    startActivityForResult(intent,FILE_REQUEST);
                    return true;
                } catch (ActivityNotFoundException ex) {
                    chooserCallback = null;
                    return false;
                }
            }
        });
        if (savedInstanceState == null) webView.loadUrl(HOME);
        else if (webView.restoreState(savedInstanceState) == null) webView.loadUrl(HOME);
    }

    private void retry() {
        errorPanel.setVisibility(View.GONE);
        if (webView.getUrl() == null || webView.getUrl().isEmpty()) webView.loadUrl(HOME);
        else webView.reload();
    }

    @Override public void onBackPressed() {
        if (errorPanel.getVisibility() == View.VISIBLE) {
            if (webView.canGoBack()) { errorPanel.setVisibility(View.GONE); webView.goBack(); }
            else retry();
        } else if (webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
    @Override protected void onSaveInstanceState(Bundle outState) {
        webView.saveState(outState);
        super.onSaveInstanceState(outState);
    }
    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode,resultCode,data);
        if (requestCode == FILE_REQUEST && chooserCallback != null) {
            chooserCallback.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode,data));
            chooserCallback = null;
        }
    }
    @Override public void onConfigurationChanged(android.content.res.Configuration config) {
        super.onConfigurationChanged(config);
    }
    @Override protected void onDestroy() {
        if (chooserCallback != null) { chooserCallback.onReceiveValue(null); chooserCallback = null; }
        if (webView != null) {
            ((ViewGroup)webView.getParent()).removeView(webView);
            webView.destroy();
        }
        super.onDestroy();
    }
}
